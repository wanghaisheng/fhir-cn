package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.2.1";
  public final static String REVISION = "2606";
  public final static String DATE = "Wed Jul 02 16:21:45 GMT+08:00 2014";
}
