﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Wed, Jul 2, 2014 16:21+0800 for FHIR v0.2.1
 */
/*
 * A server push subscription criteria
 *
 * [FhirResource("Subscription")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRString;
@class FHIRContact;
@class FHIRCode;
@class FHIRSubscriptionChannelComponent;
@class FHIRInstant;
@class FHIRSubscriptionTagComponent;

@interface FHIRSubscription : FHIRBaseResource

/*
 * The status of a subscription
 */
typedef enum 
{
    kSubscriptionStatusRequested, // The client has requested the subscription, and the server has not yet set it up.
    kSubscriptionStatusActive, // The subscription is active.
    kSubscriptionStatusError, // The server has an error executing the notification.
    kSubscriptionStatusOff, // Too many errors have occurred or the subscription has expired.
} kSubscriptionStatus;

/*
 * The type of method used to execute a subscription
 */
typedef enum 
{
    kSubscriptionChannelTypeRestHook, // The channel is executed by making a post to the URI. If a payload is included, the URL is interpreted as the service base, and an update (PUT) is made.
    kSubscriptionChannelTypeWebsocket, // The channel is executed by sending a packet across a web socket connection maintained by the client. The URL identifies the websocket, and the client binds to this URL.
    kSubscriptionChannelTypeEmail, // The channel is executed by sending an email to the email addressed in the URI (which must be a mailto:).
    kSubscriptionChannelTypeSms, // The channel is executed by sending an SMS message to the phone number identified in the URL (tel:).
    kSubscriptionChannelTypeMessage, // The channel Is executed by sending a message (e.g. a Bundle with a MessageHeader resource etc) to the application identified in the URI.
} kSubscriptionChannelType;

/*
 * Rule for server push criteria
 */
@property (nonatomic, strong) FHIRString *criteriaElement;

@property (nonatomic, strong) NSString *criteria;

/*
 * Contact details for source (e.g. troubleshooting)
 */
@property (nonatomic, strong) NSArray/*<Contact>*/ *contact;

/*
 * Description of why this subscription was created
 */
@property (nonatomic, strong) FHIRString *reasonElement;

@property (nonatomic, strong) NSString *reason;

/*
 * requested | active | error | off
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kSubscriptionStatus status;

/*
 * Latest error note
 */
@property (nonatomic, strong) FHIRString *errorElement;

@property (nonatomic, strong) NSString *error;

/*
 * The channel on which to report matches to the criteria
 */
@property (nonatomic, strong) FHIRSubscriptionChannelComponent *channel;

/*
 * When to automatically delete the subscription
 */
@property (nonatomic, strong) FHIRInstant *endElement;

@property (nonatomic, strong) NSDate *end;

/*
 * A tag to add to matching resources
 */
@property (nonatomic, strong) NSArray/*<SubscriptionTagComponent>*/ *tag;

- (FHIRErrorList *)validate;

@end
